<?php
namespace Config;
use mysqli;

/*
||------------------------------------------||
|| DATABASE CONECTION   HERE                ||
||------------------------------------------||
 */
    class Config
    {
        public static function connect()
        {
            $host = 'localhost';
            $user = $_ENV["DB_USER"];
            $pass = $_ENV["DB_PASS"];
            $db = $_ENV["DB_NAME"];
            $con = new mysqli($host, $user, $pass, $db);
            return $con->errno <= 0 ? $con : false;
        }

    }
/*
||------------------------------------------||
|| DATABASE CONECTION   HERE  END           ||
||------------------------------------------||
 */

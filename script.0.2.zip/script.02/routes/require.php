<?php
return $routes = [
    "api",
    "web",
];

<?php
/**
 * ----------------------------------------||
 * THIS CODE DON'T REMOVE FOR YOUR PROJECT ||
 * ----------------------------------------||
 */
define("SCRIPT", time());
define("BASEPATH",__DIR__);
require_once BASEPATH . "./vendor/autoload.php";
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();
runApp();

/**
 * ----------------------------------------||
 * THIS CODE DON'T REMOVE FOR YOUR PROJECT ||
 * ----------------------------------------||
 */

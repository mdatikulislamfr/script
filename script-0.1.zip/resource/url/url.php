<script>
  $(".getLink").click(function(){
        let getURL = $(this).attr('data');
        let url    = "<?php echo URL() ?>";
        let finalURL= url+'/'+getURL;
        $.ajax({
            url:finalURL,
            method:"GET",
            success:function(e){
               $("#root").html(e);
            }
        })
    })
</script>
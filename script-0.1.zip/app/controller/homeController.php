<?php 
use function vendor\script\view;
class homeController{
    public function index($get)
    {
       view("main");
    }
    function about(){
        view("about");
    }
    function home(){
        view("home");
    }
}
<?php
use vendor\script\Auth;
use vendor\script\Sql;
class Model{
    static function user($table){
        if(Auth::check()){
            $sql =new Sql;
            $data = $sql->select($table,Auth::getId(),"","assoc");
            return $data;
        }
    }
}
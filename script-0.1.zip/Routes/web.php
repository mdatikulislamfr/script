<?php
use vendor\script\Route;


Route::get("freemwork","homeController@index");
Route::get("freemwork/about","homeController@about");
Route::get("freemwork/service","homeController@service");


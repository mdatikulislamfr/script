<?php 
use env\env;
/*
    ||------------------------------------------||
    || DATABASE CONECTION   HERE                ||
    ||------------------------------------------||
        */
         class config{
               public static function Conection()
               {
                   $host   = env::DBINFO()['HOST_NAME'];
                   $user   = env::DBINFO()['USER_NAME'];
                   $pass   = env::DBINFO()['PASSWORD'];
                   $db     = env::DBINFO()['DB_NAMES'];
                   $CONECTION = new mysqli($host,$user,$pass,$db);
                   if($CONECTION){
                       return $CONECTION;
                   }else{
                       return false;
                   }
               }
               
         }
         
        /*
    ||------------------------------------------||
    || DATABASE CONECTION   HERE  END           ||
    ||------------------------------------------||
    */
<?php
  use vendor\script\Session;


  require_once __DIR__ . '/vendor/autoload.php';
  session::int();
  require_once __DIR__ . '/Routes/web.php';

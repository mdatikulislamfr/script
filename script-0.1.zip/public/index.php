<?php

// auto load all files
  require_once __DIR__ . '/../vendor/autoload.php';
  // session::int();

// run file alll

require_once __DIR__ . '/../Routes/web.php';
require_once __DIR__ . '/../Routes/ajax.php';
// page expert not found

